// DOM Elements
const uploadSection = document.getElementById('uploadSection');
const resultsSection = document.getElementById('resultsSection');
const errorSection = document.getElementById('errorSection');
const uploadForm = document.getElementById('uploadForm');
const fileInput = document.getElementById('fileInput');
const fileName = document.getElementById('fileName');
const convertBtn = document.getElementById('convertBtn');
const btnText = convertBtn.querySelector('.btn-text');
const btnLoading = convertBtn.querySelector('.btn-loading');
const newConversionBtn = document.getElementById('newConversionBtn');
const retryBtn = document.getElementById('retryBtn');
const downloadCSV = document.getElementById('downloadCSV');
const downloadExcel = document.getElementById('downloadExcel');
const transactionCount = document.getElementById('transactionCount');
const summaryGrid = document.getElementById('summaryGrid');
const categoryGrid = document.getElementById('categoryGrid');
const analysisGrid = document.getElementById('analysisGrid');
const progressContainer = document.getElementById('progressContainer');
const progressFill = document.getElementById('progressFill');
const progressText = document.getElementById('progressText');
const errorMessage = document.getElementById('errorMessage');

let currentFiles = null;

// File input change handler
fileInput.addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        fileName.textContent = `Selected: ${file.name}`;
        fileName.style.display = 'block';
        convertBtn.disabled = false;
    } else {
        fileName.textContent = '';
        fileName.style.display = 'none';
        convertBtn.disabled = true;
    }
});

// Form submission handler
uploadForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const file = fileInput.files[0];
    if (!file) {
        showError('कृपया पहले PDF file select करें');
        return;
    }

    // Validate file type
    if (file.type !== 'application/pdf') {
        showError('केवल PDF files allowed हैं');
        return;
    }

    // Start conversion process
    startConversion(file);
});

// Start conversion process
function startConversion(file) {
    convertBtn.disabled = true;
    btnText.style.display = 'none';
    btnLoading.style.display = 'inline';
    
    // Show progress bar
    progressContainer.style.display = 'block';
    animateProgress();
    
    // Create FormData object
    const formData = new FormData();
    formData.append('file', file);
    
    // Add contact information if provided
    const whatsappNumber = document.getElementById('whatsappNumber').value.trim();
    const emailAddress = document.getElementById('emailAddress').value.trim();
    
    if (whatsappNumber) {
        formData.append('whatsapp_number', whatsappNumber);
    }
    if (emailAddress) {
        formData.append('email_address', emailAddress);
    }
    
    // Send file to backend
    fetch('/upload', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            completeProgress();
            setTimeout(() => showResults(data), 500);
        } else {
            showError(data.error || 'Processing failed. Please try again.');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showError('Network error. Please check your connection and try again.');
    })
    .finally(() => {
        // Reset button state
        convertBtn.disabled = false;
        btnText.style.display = 'inline';
        btnLoading.style.display = 'none';
        progressContainer.style.display = 'none';
    });
}

// Animate progress bar
function animateProgress() {
    let progress = 0;
    const steps = [
        { progress: 20, text: 'Uploading file...' },
        { progress: 40, text: 'Reading PDF content...' },
        { progress: 60, text: 'Extracting transactions...' },
        { progress: 80, text: 'Categorizing expenses...' },
        { progress: 95, text: 'Generating reports...' }
    ];
    
    let currentStep = 0;
    
    const interval = setInterval(() => {
        if (currentStep < steps.length) {
            progress = steps[currentStep].progress;
            progressFill.style.width = progress + '%';
            progressText.textContent = steps[currentStep].text;
            currentStep++;
        } else {
            clearInterval(interval);
        }
    }, 800);
}

// Complete progress animation
function completeProgress() {
    progressFill.style.width = '100%';
    progressText.textContent = 'Conversion completed successfully!';
}

// Show results section
function showResults(data) {
    hideAllSections();
    resultsSection.style.display = 'block';
    
    // Store current files
    currentFiles = {
        csv: data.csv_file,
        excel: data.excel_file
    };
    
    // Update transaction count
    transactionCount.textContent = `${data.transaction_count} transactions processed`;
    
    // Show notification status
    showNotificationStatus(data);
    
    // Update cleanup time
    if (data.cleanup_time) {
        const cleanupElement = document.getElementById('cleanupTime');
        const cleanupDate = new Date(data.cleanup_time);
        const now = new Date();
        const minutesLeft = Math.ceil((cleanupDate - now) / (1000 * 60));
        cleanupElement.textContent = `${minutesLeft} minutes`;
    }
    
    // Populate summary
    populateSummary(data.summary);
    
    // Populate smart analysis
    populateSmartAnalysis(data.summary);
    
    // Populate categories
    populateCategories(data.summary.category_expenses);
    
    // Setup download links
    setupDownloadLinks();
}

// Populate financial summary
function populateSummary(summary) {
    const summaryItems = [
        {
            label: 'Total Debits',
            value: `₹${formatCurrency(summary.total_debits)}`,
            className: 'negative'
        },
        {
            label: 'Total Credits',
            value: `₹${formatCurrency(summary.total_credits)}`,
            className: 'positive'
        },
        {
            label: 'Net Amount',
            value: `₹${formatCurrency(summary.net_amount)}`,
            className: summary.net_amount >= 0 ? 'positive' : 'negative'
        },
        {
            label: 'Opening Balance',
            value: `₹${formatCurrency(summary.opening_balance)}`,
            className: ''
        },
        {
            label: 'Closing Balance',
            value: `₹${formatCurrency(summary.closing_balance)}`,
            className: ''
        },
        {
            label: 'Total Transactions',
            value: summary.total_transactions.toString(),
            className: ''
        }
    ];
    
    summaryGrid.innerHTML = summaryItems.map(item => `
        <div class="summary-item">
            <div class="summary-label">${item.label}</div>
            <div class="summary-value ${item.className}">${item.value}</div>
        </div>
    `).join('');
}

// Populate category breakdown
function populateCategories(categories) {
    if (!categories || Object.keys(categories).length === 0) {
        categoryGrid.innerHTML = '<p>No expense categories found</p>';
        return;
    }
    
    const categoryItems = Object.entries(categories)
        .filter(([_, amount]) => amount > 0)
        .sort(([_, a], [__, b]) => b - a)
        .map(([category, amount]) => `
            <div class="category-item">
                <div class="category-name">${category}</div>
                <div class="category-amount">₹${formatCurrency(amount)}</div>
            </div>
        `);
    
    categoryGrid.innerHTML = categoryItems.join('');
}

// Setup download links
function setupDownloadLinks() {
    downloadCSV.href = `/download/csv/${currentFiles.csv}`;
    downloadExcel.href = `/download/excel/${currentFiles.excel}`;
    
    // Add click handlers for download feedback
    downloadCSV.addEventListener('click', function() {
        showDownloadSuccess('CSV');
    });
    
    downloadExcel.addEventListener('click', function() {
        showDownloadSuccess('Excel');
    });
}

// Show download success message
function showDownloadSuccess(format) {
    const button = format === 'CSV' ? downloadCSV : downloadExcel;
    const span = button.querySelector('span');
    const originalText = span.textContent;
    
    span.textContent = 'Downloaded ✓';
    setTimeout(() => {
        span.textContent = originalText;
    }, 2000);
}

// Show error section
function showError(message) {
    hideAllSections();
    errorSection.style.display = 'block';
    errorMessage.textContent = message;
}

// Hide all sections
function hideAllSections() {
    uploadSection.style.display = 'none';
    resultsSection.style.display = 'none';
    errorSection.style.display = 'none';
}

// Reset to upload section
function resetToUpload() {
    hideAllSections();
    uploadSection.style.display = 'block';
    
    // Reset form
    uploadForm.reset();
    fileName.textContent = '';
    fileName.style.display = 'none';
    convertBtn.disabled = true;
    btnText.style.display = 'inline';
    btnLoading.style.display = 'none';
    
    // Clear contact fields
    document.getElementById('whatsappNumber').value = '';
    document.getElementById('emailAddress').value = '';
    
    // Clear current files
    currentFiles = null;
}

// Populate smart analysis section
function populateSmartAnalysis(summary) {
    const analysisCards = [];
    
    // Highest expense category
    if (summary.category_expenses && Object.keys(summary.category_expenses).length > 0) {
        const sortedCategories = Object.entries(summary.category_expenses)
            .sort(([,a], [,b]) => b - a);
        const topCategory = sortedCategories[0];
        
        analysisCards.push({
            icon: '🔥',
            title: 'Top Expense Category',
            value: topCategory[0],
            description: `₹${formatCurrency(topCategory[1])} spent this period`,
            trend: '📈'
        });
    }
    
    // Average transaction amount
    const avgTransaction = (summary.total_debits + summary.total_credits) / summary.total_transactions;
    analysisCards.push({
        icon: '💳',
        title: 'Average Transaction',
        value: `₹${formatCurrency(avgTransaction)}`,
        description: 'Per transaction average amount',
        trend: avgTransaction > 5000 ? '📈' : '📊'
    });
    
    // Spending ratio
    const spendingRatio = (summary.total_debits / summary.total_credits * 100);
    analysisCards.push({
        icon: '📊',
        title: 'Spending Ratio',
        value: `${spendingRatio.toFixed(1)}%`,
        description: 'Expenses vs Income ratio',
        trend: spendingRatio > 80 ? '⚠️' : '✅'
    });
    
    // Balance growth
    const balanceGrowth = summary.closing_balance - summary.opening_balance;
    analysisCards.push({
        icon: balanceGrowth >= 0 ? '📈' : '📉',
        title: 'Balance Change',
        value: `₹${formatCurrency(Math.abs(balanceGrowth))}`,
        description: balanceGrowth >= 0 ? 'Account growth this period' : 'Account decrease this period',
        trend: balanceGrowth >= 0 ? '🟢' : '🔴'
    });
    
    analysisGrid.innerHTML = analysisCards.map(card => `
        <div class="analysis-card">
            <div class="analysis-card-header">
                <span class="analysis-icon">${card.icon}</span>
                <span class="analysis-title">${card.title}</span>
                <span class="analysis-trend">${card.trend}</span>
            </div>
            <div class="analysis-value">${card.value}</div>
            <div class="analysis-description">${card.description}</div>
        </div>
    `).join('');
}

// Show notification status
function showNotificationStatus(data) {
    const notificationStatus = document.getElementById('notificationStatus');
    const notificationMessage = document.getElementById('notificationMessage');
    
    let messages = [];
    
    if (data.whatsapp_sent) {
        messages.push('📱 WhatsApp notification sent successfully!');
    }
    
    if (data.email_sent) {
        messages.push('📧 Email report sent successfully!');
    }
    
    if (messages.length > 0) {
        notificationStatus.className = 'notification-status success';
        notificationMessage.innerHTML = messages.join('<br>');
        notificationStatus.style.display = 'block';
    } else {
        notificationStatus.style.display = 'none';
    }
}

// Format currency numbers
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-IN', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(Math.abs(amount));
}

// Event listeners for navigation buttons
newConversionBtn.addEventListener('click', resetToUpload);
retryBtn.addEventListener('click', resetToUpload);

// Drag and drop functionality
const uploadContainer = document.querySelector('.upload-container');

uploadContainer.addEventListener('dragover', function(e) {
    e.preventDefault();
    uploadContainer.style.borderColor = '#2563eb';
    uploadContainer.style.background = '#f1f5f9';
});

uploadContainer.addEventListener('dragleave', function(e) {
    e.preventDefault();
    uploadContainer.style.borderColor = '#cbd5e1';
    uploadContainer.style.background = '#f8fafc';
});

uploadContainer.addEventListener('drop', function(e) {
    e.preventDefault();
    uploadContainer.style.borderColor = '#cbd5e1';
    uploadContainer.style.background = '#f8fafc';
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
        const file = files[0];
        if (file.type === 'application/pdf') {
            fileInput.files = files;
            fileName.textContent = `Selected: ${file.name}`;
            fileName.style.display = 'block';
            convertBtn.disabled = false;
        } else {
            showError('केवल PDF files allowed हैं');
        }
    }
});

// Pricing plan handlers
function setupPricingHandlers() {
    const registerBtn = document.querySelector('.plan-btn.register');
    const upgradeBtn = document.querySelector('.plan-btn.upgrade');
    
    if (registerBtn) {
        registerBtn.addEventListener('click', function() {
            // Simulate registration process
            showPlanModal('register');
        });
    }
    
    if (upgradeBtn) {
        upgradeBtn.addEventListener('click', function() {
            // Simulate upgrade process
            showPlanModal('upgrade');
        });
    }
}

function showPlanModal(planType) {
    const modal = document.createElement('div');
    modal.className = 'plan-modal';
    
    const modalContent = planType === 'register' ? `
        <div class="modal-content">
            <h3>Register for Free</h3>
            <p>Get 5 conversions per day + WhatsApp & Email notifications</p>
            <div class="modal-form">
                <input type="email" placeholder="Enter your email" class="modal-input">
                <input type="tel" placeholder="WhatsApp number (optional)" class="modal-input">
                <button class="modal-btn primary">Register Free</button>
                <button class="modal-btn secondary" onclick="closeModal()">Maybe Later</button>
            </div>
        </div>
    ` : `
        <div class="modal-content">
            <h3>Upgrade to Premium</h3>
            <p>Unlock unlimited conversions + AI insights for just ₹99/month</p>
            <div class="modal-form">
                <div class="premium-benefits">
                    <div class="benefit">✅ Unlimited conversions</div>
                    <div class="benefit">✅ AI-powered financial insights</div>
                    <div class="benefit">✅ Priority processing</div>
                    <div class="benefit">✅ Custom expense categories</div>
                    <div class="benefit">✅ Advanced analytics dashboard</div>
                </div>
                <button class="modal-btn primary">Pay ₹99/month</button>
                <button class="modal-btn secondary" onclick="closeModal()">Cancel</button>
            </div>
        </div>
    `;
    
    modal.innerHTML = `
        <div class="modal-overlay" onclick="closeModal()">
            <div class="modal-box" onclick="event.stopPropagation()">
                ${modalContent}
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

function closeModal() {
    const modal = document.querySelector('.plan-modal');
    if (modal) {
        modal.remove();
    }
}

// Language toggle functionality
function setupLanguageToggle() {
    const languageSelect = document.getElementById('languageSelect');
    const elements = document.querySelectorAll('[data-lang-en]');
    
    languageSelect.addEventListener('change', function() {
        const selectedLang = this.value;
        
        elements.forEach(element => {
            const langText = element.getAttribute(`data-lang-${selectedLang}`);
            if (langText) {
                if (element.tagName === 'INPUT') {
                    element.placeholder = langText;
                } else {
                    element.innerHTML = langText;
                }
            }
        });
        
        // Store language preference
        localStorage.setItem('billkaro-language', selectedLang);
    });
    
    // Load saved language preference
    const savedLang = localStorage.getItem('billkaro-language') || 'en';
    languageSelect.value = savedLang;
    if (savedLang !== 'en') {
        languageSelect.dispatchEvent(new Event('change'));
    }
}

// Mobile navigation toggle
function setupMobileNavigation() {
    const mobileToggle = document.getElementById('mobileToggle');
    const navLinks = document.querySelector('.nav-links');
    
    if (mobileToggle) {
        mobileToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            navLinks.classList.toggle('active');
        });
    }
    
    // Close mobile menu when clicking nav links
    const navLinksElements = document.querySelectorAll('.nav-link');
    navLinksElements.forEach(link => {
        link.addEventListener('click', function() {
            mobileToggle.classList.remove('active');
            navLinks.classList.remove('active');
        });
    });
}

// Navigation scroll functionality
function setupNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Update active state
            navLinks.forEach(nl => nl.classList.remove('active'));
            this.classList.add('active');
            
            // Scroll to section
            const target = this.getAttribute('href');
            if (target === '#home') {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            } else if (target === '#pricing') {
                const pricingSection = document.querySelector('.pricing-section');
                if (pricingSection) {
                    pricingSection.scrollIntoView({ behavior: 'smooth' });
                }
            } else if (target === '#login') {
                showLoginModal();
            } else if (target === '#register') {
                showPlanModal('register');
            }
        });
    });
}

// Login modal functionality
function showLoginModal() {
    const modal = document.createElement('div');
    modal.className = 'plan-modal';
    
    modal.innerHTML = `
        <div class="modal-overlay" onclick="closeModal()">
            <div class="modal-box" onclick="event.stopPropagation()">
                <div class="modal-content">
                    <h3>Login to BillKaro</h3>
                    <p>Access your account and conversion history</p>
                    <div class="modal-form">
                        <input type="email" placeholder="Email address" class="modal-input">
                        <input type="password" placeholder="Password" class="modal-input">
                        <button class="modal-btn primary">Login</button>
                        <button class="modal-btn secondary" onclick="closeModal()">Cancel</button>
                    </div>
                    <div style="margin-top: 15px; text-align: center;">
                        <small><a href="#" style="color: #2563eb;">Forgot password?</a></small>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

// Support chat functionality
function toggleChat() {
    const chatPopup = document.getElementById('chatPopup');
    const isVisible = chatPopup.style.display === 'block';
    
    if (isVisible) {
        chatPopup.style.display = 'none';
    } else {
        chatPopup.style.display = 'block';
    }
}

// Chat option handlers
function setupChatHandlers() {
    const chatOptions = document.querySelectorAll('.chat-option');
    
    chatOptions.forEach(option => {
        option.addEventListener('click', function() {
            const topic = this.textContent.trim();
            showChatResponse(topic);
        });
    });
}

function showChatResponse(topic) {
    const chatContent = document.querySelector('.chat-content');
    const responses = {
        'Upload Issues': 'Make sure your PDF file is from a supported Indian bank (SBI, ICICI, HDFC, etc.) and is under 10MB. Try refreshing the page if upload fails.',
        'अपलोड की समस्या': 'सुनिश्चित करें कि आपकी PDF फ़ाइल समर्थित भारतीय बैंक (SBI, ICICI, HDFC, आदि) से है और 10MB से कम है।',
        'Pricing Questions': 'We offer 3 plans: Anonymous (1 conversion/day), Registered (5/day), and Premium (unlimited for ₹99/month). All plans include smart categorization!',
        'प्राइसिंग प्रश्न': 'हम 3 प्लान ऑफर करते हैं: Anonymous (1/दिन), Registered (5/दिन), और Premium (₹99/महीने के लिए unlimited)।',
        'Technical Support': 'For technical issues, try clearing your browser cache, disable ad blockers, or contact us at support@billkaro.com',
        'तकनीकी सहायता': 'तकनीकी समस्याओं के लिए, अपना ब्राउज़र कैश साफ़ करें या support@billkaro.com पर संपर्क करें।'
    };
    
    const response = responses[topic] || responses['Technical Support'];
    
    const responseMessage = document.createElement('div');
    responseMessage.className = 'chat-message bot';
    responseMessage.innerHTML = `<p>${response}</p>`;
    
    chatContent.appendChild(responseMessage);
    
    // Scroll to bottom
    chatContent.scrollTop = chatContent.scrollHeight;
}

// Initialize the app
document.addEventListener('DOMContentLoaded', function() {
    convertBtn.disabled = true;
    
    // Setup all functionalities
    setupPricingHandlers();
    setupLanguageToggle();
    setupMobileNavigation();
    setupNavigation();
    setupChatHandlers();
    
    // Add some entrance animation
    setTimeout(() => {
        document.querySelector('.container').style.opacity = '1';
    }, 100);
});

// Make functions globally available for onclick handlers
window.toggleChat = toggleChat;
window.closeModal = closeModal;